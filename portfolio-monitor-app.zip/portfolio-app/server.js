const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// ============================================
// CONFIGURACIÓN DE USUARIOS
// ============================================
// Los usuarios se cargan desde una variable de entorno USERS
// Formato: "usuario1:hash1;usuario2:hash2;usuario3:hash3"
// Para generar hashes, ver el script /generate-hash.js
// ============================================

function loadUsers() {
  const usersEnv = process.env.USERS || '';
  const users = {};
  if (!usersEnv) {
    console.error('⚠️  No hay usuarios configurados. Setea la variable USERS en Railway.');
    return users;
  }
  usersEnv.split(';').forEach(pair => {
    const [user, hash] = pair.split(':');
    if (user && hash) users[user.trim()] = hash.trim();
  });
  return users;
}

const USERS = loadUsers();
console.log(`✓ ${Object.keys(USERS).length} usuario(s) cargado(s):`, Object.keys(USERS).join(', '));

// ============================================
// MIDDLEWARES
// ============================================
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(session({
  secret: process.env.SESSION_SECRET || 'cambiar-en-produccion',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    maxAge: 1000 * 60 * 60 * 24 * 7  // 7 días
  }
}));

// Middleware de auth
function requireAuth(req, res, next) {
  if (req.session && req.session.user) return next();
  res.redirect('/login');
}

// ============================================
// RUTAS
// ============================================

// Página de login
app.get('/login', (req, res) => {
  if (req.session && req.session.user) return res.redirect('/');
  const error = req.query.error ? '<div class="error">Usuario o contraseña incorrectos</div>' : '';
  res.send(`<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — Portfolio Monitor</title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@400;500&family=Inter+Tight:wght@400;500;600&display=swap" rel="stylesheet">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
  background: #0d1117;
  color: #e6edf3;
  font-family: 'Inter Tight', system-ui, sans-serif;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}
body::before {
  content: '';
  position: fixed;
  inset: 0;
  background:
    radial-gradient(circle at 20% 0%, rgba(212,175,55,0.06) 0%, transparent 50%),
    radial-gradient(circle at 80% 100%, rgba(88,166,255,0.04) 0%, transparent 50%);
  pointer-events: none;
}
.login-card {
  background: #161b22;
  border: 1px solid #30363d;
  padding: 48px 40px;
  width: 100%;
  max-width: 400px;
  position: relative;
  z-index: 1;
}
.brand {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 11px;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  color: #6e7681;
  margin-bottom: 32px;
}
.dot { width: 6px; height: 6px; border-radius: 50%; background: #d4af37; box-shadow: 0 0 12px #d4af37; }
h1 {
  font-family: 'Fraunces', Georgia, serif;
  font-weight: 400;
  font-size: 32px;
  letter-spacing: -0.02em;
  margin-bottom: 8px;
}
h1 em { color: #d4af37; font-style: italic; }
.subtitle { color: #8b949e; font-size: 14px; margin-bottom: 32px; }
.field { margin-bottom: 16px; }
label {
  display: block;
  font-size: 11px;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: #6e7681;
  margin-bottom: 6px;
  font-weight: 500;
}
input {
  width: 100%;
  background: #0d1117;
  border: 1px solid #30363d;
  color: #e6edf3;
  padding: 12px 14px;
  font-family: 'Inter Tight', sans-serif;
  font-size: 14px;
  transition: border 0.2s;
}
input:focus { outline: none; border-color: #d4af37; }
button {
  width: 100%;
  background: #d4af37;
  color: #0d1117;
  border: none;
  padding: 14px;
  font-family: 'Inter Tight', sans-serif;
  font-weight: 600;
  font-size: 14px;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  cursor: pointer;
  margin-top: 8px;
  transition: opacity 0.2s;
}
button:hover { opacity: 0.9; }
.error {
  background: rgba(248,81,73,0.12);
  color: #f85149;
  padding: 10px 14px;
  font-size: 13px;
  margin-bottom: 16px;
  border-left: 2px solid #f85149;
}
.footer {
  margin-top: 24px;
  text-align: center;
  font-size: 11px;
  color: #6e7681;
  letter-spacing: 0.05em;
}
</style>
</head>
<body>
<div class="login-card">
  <div class="brand"><span class="dot"></span>Casimiro Félix Toyos e Hijos</div>
  <h1>Portfolio <em>Monitor</em></h1>
  <p class="subtitle">Iniciá sesión para acceder al dashboard.</p>
  ${error}
  <form method="POST" action="/login">
    <div class="field">
      <label>Usuario</label>
      <input type="text" name="username" autocomplete="username" required autofocus>
    </div>
    <div class="field">
      <label>Contraseña</label>
      <input type="password" name="password" autocomplete="current-password" required>
    </div>
    <button type="submit">Ingresar</button>
  </form>
  <div class="footer">Acceso restringido</div>
</div>
</body>
</html>`);
});

// Procesar login
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const hash = USERS[username];
  if (!hash) return res.redirect('/login?error=1');

  try {
    const ok = await bcrypt.compare(password, hash);
    if (!ok) return res.redirect('/login?error=1');
    req.session.user = username;
    res.redirect('/');
  } catch (e) {
    console.error('Error en login:', e);
    res.redirect('/login?error=1');
  }
});

// Logout
app.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

// Dashboard (protegido)
app.get('/', requireAuth, (req, res) => {
  const html = fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf8');
  // Inyectar nombre de usuario y botón de logout
  const userBadge = `
    <div style="position:fixed; top:16px; right:16px; z-index:1000; display:flex; gap:12px; align-items:center; background:rgba(13,17,23,0.85); backdrop-filter:blur(12px); padding:8px 14px; border:1px solid #30363d; font-family:'JetBrains Mono', monospace; font-size:11px; letter-spacing:0.05em;">
      <span style="color:#8b949e;">👤 ${req.session.user}</span>
      <a href="/logout" style="color:#d4af37; text-decoration:none; border-left:1px solid #30363d; padding-left:12px;">SALIR</a>
    </div>`;
  const injected = html.replace('<body>', '<body>' + userBadge);
  res.send(injected);
});

// Healthcheck para Railway
app.get('/health', (req, res) => res.json({ status: 'ok', users: Object.keys(USERS).length }));

// Servir assets estáticos (si los hubiera)
app.use('/assets', express.static(path.join(__dirname, 'public', 'assets')));

app.listen(PORT, () => {
  console.log(`✓ Portfolio Monitor corriendo en puerto ${PORT}`);
});
